package com.gubo.check_weather.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PlaceResponse {
    private List<Prediction> predictionList;
    private String status;

    @Getter
    @Setter
    public static class Prediction{
        private String description;
        private String place_id;
    }
}
